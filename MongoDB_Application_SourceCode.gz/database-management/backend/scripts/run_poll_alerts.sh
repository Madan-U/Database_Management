#!/bin/bash
# Author      : Madan U
# Email       : madan.u@kotak.com
# Date        : 2026-09-12
# Script Path : /data/database-management/backend/scripts/run_poll_alerts.sh
# Description : Cron wrapper for poll_alerts.py. Cron runs with a minimal
#               environment, so this activates the venv explicitly and
#               appends timestamped output to a dedicated log file rather
#               than relying on cron's own mail delivery. Meant to run every
#               1 minute — see deploy/README.md "Alert polling".

set -euo pipefail

APP_DIR="/data/database-management/backend"
LOG_FILE="/data/database-management/logs/alerts-cron.log"

cd "$APP_DIR"
source venv/bin/activate

{
  echo "===== $(date -u '+%Y-%m-%d %H:%M:%S UTC') alert poll ====="
  python scripts/poll_alerts.py
} >> "$LOG_FILE" 2>&1
