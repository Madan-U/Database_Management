#!/bin/bash
# Author      : Madan U
# Email       : madan.u@kotak.com
# Date        : 2026-09-10
# Script Path : /data/database-management/backend/scripts/run_static_inventory_collect.sh
# Description : Cron wrapper for collect_static_inventory.py. Cron runs with a
#               minimal environment, so this activates the venv explicitly
#               and appends timestamped output to a dedicated log file rather
#               than relying on cron's own mail delivery.

set -euo pipefail

APP_DIR="/data/database-management/backend"
LOG_FILE="/data/database-management/logs/static-inventory-cron.log"

cd "$APP_DIR"
source venv/bin/activate

{
  echo "===== $(date -u '+%Y-%m-%d %H:%M:%S UTC') starting static inventory collection ====="
  python scripts/collect_static_inventory.py
  echo "===== $(date -u '+%Y-%m-%d %H:%M:%S UTC') finished ====="
} >> "$LOG_FILE" 2>&1
