#!/bin/bash
# Author      : Madan U
# Email       : madan.u@kotak.com
# Date        : 2026-09-15
# Script Path : /data/database-management/backend/scripts/run_scheduled_operations.sh
# Description : Cron wrapper for run_scheduled_operations.py. Same pattern as
#               run_static_inventory_collect.sh — activates the venv
#               explicitly (cron runs with a minimal environment) and
#               appends timestamped output to a dedicated log file.

set -euo pipefail

APP_DIR="/data/database-management/backend"
LOG_FILE="/data/database-management/logs/scheduled-operations-cron.log"

cd "$APP_DIR"
source venv/bin/activate

{
  echo "===== $(date -u '+%Y-%m-%d %H:%M:%S UTC') checking scheduled operations ====="
  python scripts/run_scheduled_operations.py
  echo "===== $(date -u '+%Y-%m-%d %H:%M:%S UTC') finished ====="
} >> "$LOG_FILE" 2>&1
