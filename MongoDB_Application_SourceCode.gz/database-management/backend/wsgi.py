"""
Author      : Madan U
Email       : madan.u@kotak.com
Date        : 2026-09-09
Script Path : /data/database-management/backend/wsgi.py
Description : WSGI entrypoint used by gunicorn in production.
               gunicorn -c gunicorn.conf.py wsgi:app
"""

from app import create_app

app = create_app()
