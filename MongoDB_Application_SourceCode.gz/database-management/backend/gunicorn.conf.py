"""
Author      : Madan U
Email       : madan.u@kotak.com
Date        : 2026-09-09
Script Path : /data/database-management/backend/gunicorn.conf.py
Description : Gunicorn runtime config for Atlas Control. Binds to localhost
               only — nginx is the public-facing edge (see deploy/README.md);
               gunicorn is never exposed directly on the network interface.
"""

import multiprocessing

bind = "127.0.0.1:8000"
workers = min(4, multiprocessing.cpu_count() * 2 + 1)
worker_class = "gthread"
threads = 4
timeout = 60
graceful_timeout = 30
keepalive = 5

accesslog = "/data/database-management/logs/gunicorn-access.log"
errorlog = "/data/database-management/logs/gunicorn-error.log"
loglevel = "info"

pidfile = "/data/database-management/logs/gunicorn.pid"
